//  DetailViewController.swift
//  TodoList
//
//  Created by Eddy R on 05/08/2020.
//  Copyright © 2020 Eddy R. All rights reserved.
//  BOSS know info


import UIKit

protocol TapSaveDelegate {
  func didTapForSave(title:String)
  func didTapForSaveEdit(obj:TodoModel)
}

class DetailViewController: UIViewController, UITextFieldDelegate {
  @IBOutlet private weak var titleTodo: UITextField!
  @IBOutlet private weak var buttonSave: UIButton!
  var delegateTapSave:TapSaveDelegate!
  var todoCurrentDetails:TodoModel?
  var todoCurrentDetailsTuple:(Int,TodoModel)?

  override func viewDidLoad() {
    super.viewDidLoad()
    titleTodo.delegate = self
    
    //retrieve data in textfield
//    if todoCurrentDetails == nil {
//      navigationItem.title = "Add Toto"
//    } else {
//      hideButton(false)
//      navigationItem.title = "Edit Toto"
//    }
    
    if todoCurrentDetailsTuple == nil {
      navigationItem.title = "Add Toto"
    } else {
      hideButton(false)
      navigationItem.title = "Edit Toto"
      titleTodo.text = todoCurrentDetailsTuple?.1.title
    }
    
    
  }
  internal func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
    let userEnteredString = textField.text
    let newString = (userEnteredString! as NSString).replacingCharacters(in: range, with: string) as NSString
    if newString != "" {
      hideButton(false)
    } else {
      hideButton(true)
    }
    return true
  }
  
  private func hideButton(_ boolValue:Bool) {
    buttonSave.isHidden = boolValue
  }
  
  
  @IBAction func actionSave(_ sender: Any) {
    
    // if nil == add else edit
//    print("  💟🐝\(#line)💟▓▒░ todoCurrentDetails ░▒▓💟",todoCurrentDetailsTuple,"💟")
    if todoCurrentDetailsTuple == nil {
      
      // check if textfield has character
      if let title = titleTodo.text {
          delegateTapSave.didTapForSave(title: title )
          dismiss(animated: true, completion: nil)
      } else {
        delegateTapSave.didTapForSave(title: "" )
        dismiss(animated: true, completion: nil)
      }
      
    } else {
      //edit side
//      print("  💟 nil 02💟")
      todoCurrentDetails?.title = "toto"
      todoCurrentDetailsTuple?.1.title = titleTodo.text!
      print("------ todoCurrentDetailsTuple?.1",todoCurrentDetailsTuple?.1)
      delegateTapSave.didTapForSaveEdit(obj:todoCurrentDetailsTuple!.1)
    }
    navigationController?.popViewController(animated: true)
  }
}
