//
//  ViewController.swift
//  TodoList
//
//  Created by Eddy R on 05/08/2020.
//  Copyright © 2020 Eddy R. All rights reserved.
// inter acting with info
 
import UIKit
import os.log

class ViewController: UIViewController {
  
  // Mark:Propreties
  @IBOutlet weak var tableView: UITableView!
  
  var todoList = [
    TodoModel(title: "One"),
    TodoModel(title: "Two"),
    TodoModel(title: "Three")
  ]
  override func viewDidLoad() {
    super.viewDidLoad()
    tableView.dataSource = self
  }
  
  
//  // @IBACTION
//  @IBAction func actionAdd3(_ sender: Any) {
//    let vc = storyboard?.instantiateViewController(withIdentifier: "DetailViewController") as! DetailViewController
//    print(vc)
//    vc.delegateTapSave = self
//    present(vc, animated: true, completion: nil)
//  }
//  @IBAction func actionAdd(_ sender: Any) {
//    let vss = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(identifier: "DetailViewController") as! DetailViewController
//    vss.delegateTapSave = self
//    present(vss, animated: true, completion: nil)
//  }
}

extension ViewController: UITableViewDataSource {
  func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    return todoList.count
  }
  func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
    cell.textLabel?.text = todoList[indexPath.row].title
    
    return cell
  }
}


extension ViewController: UITableViewDelegate {
  //delete
  func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
    if (editingStyle == UITableViewCell.EditingStyle.delete) {
      print("██░░░ -- L\(#line) ⭐️⭐️ delete ⭐️⭐️\n")
      todoList.remove(at: indexPath.row)
      tableView.deleteRows(at: [indexPath], with: UITableView.RowAnimation.automatic)
    }
  }

  override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
    super.prepare(for: segue, sender: sender)
    
    if segue.identifier == "AddTodo" {
      os_log("ADD todo", log:OSLog.default, type: .debug)
      let vcDestinationDetailViewController = segue.destination as! DetailViewController
      vcDestinationDetailViewController.delegateTapSave = self
    }
    
    if segue.identifier == "EditTodo" {
      print("EditTodo")
      
      let vcDestinationDetailViewController = segue.destination as! DetailViewController
      vcDestinationDetailViewController.delegateTapSave = self
      
      if let index = tableView.indexPathForSelectedRow?.row {
//        vcDestinationDetailViewController.todoCurrentDetails = todoList[index]
        vcDestinationDetailViewController.todoCurrentDetailsTuple = (index,todoList[index])
      }
    }
    
  }
}





extension ViewController: TapSaveDelegate {
  func didTapForSaveEdit(obj: TodoModel) {
    let toto = todoList.map { (t) -> String in
      return t.title
    }
    print("  💟🐝\(#line)💟▓▒░ toto ░▒▓💟",toto,"💟")
  }
  
  func didTapForSave(title: String) {
    todoList.append(TodoModel(title: title))
    tableView.reloadData()
  }
}
