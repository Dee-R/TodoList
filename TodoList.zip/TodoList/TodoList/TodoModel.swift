//
//  TodoModel.swift
//  TodoList
//
//  Created by Eddy R on 05/08/2020.
//  Copyright © 2020 Eddy R. All rights reserved.
//

import Foundation

struct TodoModel{
    var id: String = NSUUID().uuidString
    var title: String
    
//    let uuid = NSUUID().uuidString
  init (title:String) {
        self.title = title
    }
}
